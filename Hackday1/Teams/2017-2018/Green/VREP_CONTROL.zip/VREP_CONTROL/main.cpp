/*   CODIGO DE ROBOT ESQUIVA-OBSTACULOS CON V-REP

     Escrito por Nano en beneficio de los seres humanos
     www.robologs.net
*/

#include <iostream>

extern "C" {
    #include "extApi.h"
}

using namespace std;

int main()
{

	//Variables para guardar motores
	int motor_1;
	int motor_2;
	int motor_3;
	int motor_4;

	//Variable que guarda el obstaculo detectado
	simxUChar obstaculo;

	//Variable para guardar el sensor de distancia
	int sensor;


	int clientID=simxStart("127.0.0.1",19997,true,true,100,5); //Conectar con la simulacion
	if(clientID == -1) //Si clientID vale -1, es que no se ha conectado con exito
	{
		cout << "ERROR: No se ha podido conectar\n";
		simxFinish(clientID); //Siempre hay que cerrar la conexion
		return 0;
	}

	//Aqui guardamos los dos motores y el sensor
	int valido1 = simxGetObjectHandle(clientID, "motor_1", &motor_1, simx_opmode_blocking);
	int valido2 = simxGetObjectHandle(clientID, "motor_2", &motor_2, simx_opmode_blocking);
	int valido3 = simxGetObjectHandle(clientID, "motor_3", &motor_3, simx_opmode_blocking);
	int valido4 = simxGetObjectHandle(clientID, "motor_4", &motor_4, simx_opmode_blocking);
	int valido_sensor = simxGetObjectHandle(clientID, "sensor", &sensor, simx_opmode_blocking);

	//Si no se ha podido acceder a alguno de estos componentes mostramos un mensaje de error y salimos del programa
	if(valido1 != 0 || valido2 != 0 || valido3 != 0 || valido4 != 0 || valido_sensor != 0)
	{
		cout << "ERROR: No se ha podido conectar con el robot" << endl;
		simxFinish(clientID);
		return 0;
	}

	//Inicializar el sensor
	simxReadProximitySensor(clientID,sensor,&obstaculo,NULL,NULL,NULL,simx_opmode_streaming);
	
	

	while (simxGetConnectionId(clientID)!=-1) //Este bucle funcionara hasta que se pare la simulacion
	{	
			simxReadProximitySensor(clientID,sensor,&obstaculo,NULL,NULL,NULL,simx_opmode_buffer); //Leer el sensor
			if(obstaculo == 0) //Si no se detecta ningun obstaculo, avanzar
			{
				simxSetJointTargetVelocity(clientID,motor_1,-2,simx_opmode_oneshot);
				simxSetJointTargetVelocity(clientID,motor_2,-2,simx_opmode_oneshot);
				simxSetJointTargetVelocity(clientID,motor_3,-2,simx_opmode_oneshot);
				simxSetJointTargetVelocity(clientID,motor_4,-2,simx_opmode_oneshot);
			}
			else //Giraremos si encontramos algo en el camino del robot
			{
				simxSetJointTargetVelocity(clientID,motor_1, 2,simx_opmode_oneshot);
				simxSetJointTargetVelocity(clientID,motor_2, -2,simx_opmode_oneshot);
				simxSetJointTargetVelocity(clientID,motor_3, 2,simx_opmode_oneshot);
				simxSetJointTargetVelocity(clientID,motor_4, -2,simx_opmode_oneshot);
			}


	}

	simxFinish(clientID); //Siempre hay que parar la simulación
	cout << "Simulacion finalizada" << endl;
	return 0;
}

